# mypackage

This is for a boring class

# How to install

Run the code